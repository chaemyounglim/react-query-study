import type { Appointment } from '../../../../shared/types';

export type AppointmentDateMap = Record<number, Appointment[]>;
